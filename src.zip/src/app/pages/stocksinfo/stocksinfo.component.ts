import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stocksinfo',
  templateUrl: './stocksinfo.component.html',
  styleUrls: ['./stocksinfo.component.css']
})
export class StocksinfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
