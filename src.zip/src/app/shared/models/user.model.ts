export class User {
    //    uid: String;
        fullName: String;
        email: String;
        password: String;
    //    status: String;
    }
    